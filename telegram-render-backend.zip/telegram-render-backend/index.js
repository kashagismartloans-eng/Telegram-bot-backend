const { Telegraf } = require("telegraf");

const token = process.env.BOT_TOKEN;

if (!token) {
  console.error("Missing BOT_TOKEN environment variable.");
  process.exit(1);
}

const bot = new Telegraf(token);

bot.start((ctx) => {
  ctx.reply(
    `Welcome, ${ctx.from.first_name || "there"}! Your Telegram bot is connected and running.`
  );
});

bot.help((ctx) => {
  ctx.reply(
    "Available commands:\n/start - Start the bot\n/help - Show help\n/id - Show your Telegram user ID"
  );
});

bot.command("id", (ctx) => {
  ctx.reply(`Your Telegram user ID is: ${ctx.from.id}`);
});

bot.on("text", (ctx) => {
  ctx.reply(`You sent: ${ctx.message.text}`);
});

bot.catch((err, ctx) => {
  console.error(`Telegram bot error while handling update ${ctx.update.update_id}:`, err);
});

async function startBot() {
  try {
    await bot.launch();
    console.log("Telegram bot started successfully using long polling.");
  } catch (error) {
    console.error("Could not start Telegram bot:", error);
    process.exit(1);
  }
}

async function stopBot(signal) {
  console.log(`Received ${signal}; stopping bot...`);
  bot.stop(signal);
  process.exit(0);
}

process.once("SIGINT", () => stopBot("SIGINT"));
process.once("SIGTERM", () => stopBot("SIGTERM"));

startBot();
