# Telegram bot backend for Render

This starter bot uses Telegram long polling with Telegraf. Deploy it to Render as a **Background Worker** (not a Web Service).

## 1. Protect your bot token

If you have ever pasted your Telegram bot token into a chat, screenshot, public repository, or website, revoke it through **@BotFather** and generate a new one. Do not put the token in `index.js`, GitHub, or any public file.

## 2. Upload to GitHub

1. Create a new GitHub repository.
2. Upload `index.js`, `package.json`, `.gitignore`, and this README.
3. Do not upload a real `.env` file or token.

## 3. Deploy on Render

1. Sign in to Render and choose **New + → Background Worker**.
2. Connect the GitHub repository.
3. Set the runtime to **Node**.
4. Set the build command to `npm install`.
5. Set the start command to `npm start`.
6. Under **Environment Variables**, add:
   - Key: `BOT_TOKEN`
   - Value: your newly generated Telegram bot token
7. Create the Background Worker and check its logs. You should see:
   `Telegram bot started successfully using long polling.`

## 4. Test it

Open your bot in Telegram and send `/start`, `/help`, or `/id`. It also echoes ordinary text messages.

## Notes

- This project uses long polling, so it does not need a webhook URL or an Express web server.
- Keep the Render Background Worker running.
- Never share your bot token. Anyone who has it may be able to control your bot.
